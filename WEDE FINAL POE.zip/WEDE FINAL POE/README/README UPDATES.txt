## Part 2: CSS Styling and Responsive Design

The website now uses an external stylesheet, `style.css`, linked from `index.html`.
The stylesheet contains the shared base styles, typography, layout, visual design,
interaction states, and responsive breakpoints.

### Responsive testing evidence

Add screenshots of the website at desktop, tablet, and mobile sizes here. Capture
them using browser developer tools' device emulation, and save the images in a
repository folder such as `screenshots/`.

- Desktop: `screenshots/desktop.png`
- Tablet: `screenshots/tablet.png`
- Mobile: `screenshots/mobile.png`

### Changelog

- **Part 2:** Created and linked `style.css` as the external stylesheet.
- **Part 2:** Added a CSS reset, consistent typography, colour palette, spacing,
  card styling, and keyboard-focus styles.
- **Part 2:** Reorganised content into responsive Grid and Flexbox layouts for
  the About, Services, Portfolio, Testimonials, and Contact sections.
- **Part 2:** Added tablet and mobile media queries so multi-column sections
  collapse to a single column on smaller screens.
- **Part 2:** Made images responsive with `max-width: 100%`, descriptive alt
  text, and lazy loading for content images.
- **Part 2:** Improved navigation and form accessibility with a skip link,
  descriptive labels, required fields, and visible focus states.
- **Part 2:** Corrected the About navigation target and improved the page title,
  contact links, and page structure.

## References

- MDN Web Docs, CSS: https://developer.mozilla.org/en-US/docs/Web/CSS
- MDN Web Docs, Responsive design: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design
- MDN Web Docs, HTML forms: https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms
